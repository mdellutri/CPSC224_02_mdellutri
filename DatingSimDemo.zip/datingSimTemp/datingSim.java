/*********
 final project
 Name: Sam Schoenberg, Mason Dellutri
 *********/
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.Timer;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
//import java.util.concurrent
public class datingSim extends JFrame{

    BufferedImage defaultBackground;
    BufferedImage coffeeBackground;
    BufferedImage deskBackground;
    BufferedImage parkBackground;
    BufferedImage Sprite;
    BufferedImage Textbox;
    BufferedImage choiceUnselected;
    BufferedImage choiceSelected;
    BufferedImage Selection;
    BufferedImage Empty;
    BufferedImage laptopHappy;
    BufferedImage laptopGasp;
    BufferedImage laptopSad;
    BufferedImage smartphoneHappy;
    BufferedImage smartphoneGasp;
    BufferedImage smartphoneSad;
    BufferedImage desktopHappy;
    BufferedImage desktopGasp;
    BufferedImage desktopSad;
    String textLine1;
    String textLine2;
    String textLine3;
    Boolean selection1 = false;
    Boolean selection2 = false;
    Boolean selection3 = false;

    datingSim() throws java.io.IOException
    {
        init();
        loadSprites();
        setTitle("datingSim");
        setSize(500, 500);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

    }

    public void loadSprites() throws IOException{
        defaultBackground = ImageIO.read(new File("defaultBackground.png"));
        coffeeBackground = ImageIO.read(new File("coffeeBackground.png"));
        deskBackground = ImageIO.read(new File("deskBackground.png"));
        parkBackground = ImageIO.read(new File("parkBackground.png"));
        Sprite = ImageIO.read(new File("smartphoneHappy.png"));
        Textbox = ImageIO.read(new File("textboxSprite.png"));
        choiceUnselected = ImageIO.read(new File("choiceUnselected.png"));
        choiceSelected = ImageIO.read(new File("choiceSelected.png"));
        Selection = ImageIO.read(new File("selection.png"));
        Empty = ImageIO.read(new File("emptySprite.png"));
        laptopHappy = ImageIO.read(new File("laptopHappy.png"));;
        laptopGasp = ImageIO.read(new File("laptopGasp.png"));;
        laptopSad = ImageIO.read(new File("laptopSad.png"));;
        smartphoneHappy = ImageIO.read(new File("smartphoneHappy.png"));;
        smartphoneGasp = ImageIO.read(new File("smartphoneGasp.png"));;
        smartphoneSad = ImageIO.read(new File("smartphoneSad.png"));;
        desktopHappy = ImageIO.read(new File("desktopHappy.png"));;
        desktopGasp = ImageIO.read(new File("desktopGasp.png"));;
        desktopSad = ImageIO.read(new File("desktopSad.png"));;
        textLine1 = "Choice 1";
        textLine2 = "Choice 2";
        textLine3 = "Choice 3";
    }
    
    public void init() throws java.io.IOException
    {
        // tempBackground = ImageIO.read(new File("tempBackground.png"));
        // tempSprite = ImageIO.read(new File("tempSprite.png"));
        //  textboxSprite = ImageIO.read(new File("textboxSprite.png"));
        addMouseListener(new MyMouseListener());
        addMouseMotionListener(new MyMouseMotionListener());
    }
    
    public void paint(Graphics g)
    {
        g.drawImage(parkBackground, 0, 0, null);
        g.drawImage(Sprite, 0, 0, null);     
        //**Below is how we display the choices */
        if(selection1 == true){
            g.drawImage(choiceSelected, 50, 350, null);
        }
        else{
            g.drawImage(choiceUnselected, 50, 350, null);
        }
        g.drawString(textLine1, 80, 380);
        if(selection2 == true){
            g.drawImage(choiceSelected, 200, 350, null);
        }
        else{
            g.drawImage(choiceUnselected, 200, 350, null);
        }
        g.drawString(textLine2, 230, 380);
        if(selection3 == true){
            g.drawImage(choiceSelected, 350, 350, null);
        }
        else{
            g.drawImage(choiceUnselected, 350, 350, null);
        }
        g.drawString(textLine3, 380, 380);
        //**Below is how we would display the dialogue**
        //g.drawImage(Textbox, 0, 350, null);
        //g.drawString(textLine1, 40, 380);
        // g.drawString(textLine2, 40, 400);
        // g.drawString(textLine3, 40, 420);
    }
    
    /**
     Mouse listener class
     */
    
    private class MyMouseListener
    implements MouseListener
    {
        public void mousePressed(MouseEvent e)
        {
            // if ((e.getY()>390)&&(e.getY()<410)){
            //     Sprite = smartphoneGasp;
            //     repaint();
            // }
            // else if((e.getY()>410)&&(e.getY()<440)){
            //     Sprite = smartphoneSad;
            //     repaint();
            // }
        }
        
        //
        // The following methods are unused, but still
        // required by the MouseListener interface.
        //
        
        public void mouseClicked(MouseEvent e)
        {
         if ((e.getY()>349)&&(e.getY()<450)){
            if ((e.getX()>50)&&(e.getX()<150)){
                if(selection1 == false)
                {
                    selection1 = true;
                }
                else if(selection1 == true)
                {
                    selection1 = false;
                }
                selection2 = false;
                selection3 = false;
            }
            else if ((e.getX()>200)&&(e.getX()<300)){
                if(selection2 == false)
                {
                    selection2 = true;
                }
                else if(selection2 == true)
                {
                    selection2 = false;
                }
                selection1 = false;
                selection3 = false;
            }
            else if ((e.getX()>350)&&(e.getX()<450)){
                if(selection3 == false)
                {
                    selection3 = true;
                }
                else if(selection3 == true)
                {
                    selection3 = false;
                }
                selection2 = false;
                selection1 = false;
            }
            repaint();
        }
        }
        
        public void mouseReleased(MouseEvent e)
        {

        }
        
        public void mouseEntered(MouseEvent e)
        {
        }
        
        public void mouseExited(MouseEvent e)
        {
        }
    }
    
    /**
     Mouse Motion listener class
     */
    
    private class MyMouseMotionListener
    implements MouseMotionListener
    {
        public void mouseDragged(MouseEvent e)
        {

        }
        
        /**
         The mouseMoved method is unused, but still
         required by the MouseMotionListener interface.
         */
        
        public void mouseMoved(MouseEvent e)
        {
            // if ((e.getY()>390)&&(e.getY()<410)){
            //     selection2 = true;
            //     repaint();
            // }
            // else if((e.getY()>410)&&(e.getY()<440)){
            //     selection3 = true;
            //     repaint();
            // }
            // else
            // {
            //     selection2 = false;
            //     selection3 = false;
            //     repaint();
            // }
        }
    }
    
//    private class TimerListener
//     implements ActionListener
//     {
//     }
    
    public static void main(String[] args) throws java.io.IOException
    {
        try {
        new datingSim();
    }
    catch(IOException e) {
       // Code to handle an IOException here
       System.out.println("Could not find file");
    }
    }
}	
